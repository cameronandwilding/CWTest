<?php

namespace NamespaceCollision\C;

class Foo
{
    public static $loaded = true;
}
