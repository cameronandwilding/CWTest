<?php

namespace Acme\DemoLib;

class Class_With_Underscores
{
}
