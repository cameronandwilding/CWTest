<?php

namespace ClassesWithParents;

class A extends B
{
}
