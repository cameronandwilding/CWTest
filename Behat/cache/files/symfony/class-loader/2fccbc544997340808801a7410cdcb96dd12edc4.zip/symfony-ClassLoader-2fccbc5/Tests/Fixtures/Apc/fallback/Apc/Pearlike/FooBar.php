<?php

class Apc_Pearlike_FooBar
{
    public static $loaded = true;
}
