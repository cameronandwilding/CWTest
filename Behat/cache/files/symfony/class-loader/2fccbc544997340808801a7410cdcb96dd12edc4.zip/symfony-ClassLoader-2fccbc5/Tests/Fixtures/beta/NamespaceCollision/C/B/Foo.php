<?php

namespace NamespaceCollision\C\B;

class Foo
{
    public static $loaded = true;
}
