<?php
$cookieAtRootPath = false;
$cookieValue = 'srv_var_is_set_sub_folder';
require_once __DIR__ . '/../' . basename(__FILE__);
