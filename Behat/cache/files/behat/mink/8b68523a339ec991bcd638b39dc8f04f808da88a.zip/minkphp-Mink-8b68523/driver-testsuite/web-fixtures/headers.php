<!DOCTYPE html>
<html>
<head>
    <title>Headers page</title>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
</head>
<body>
    <?php print_r($_SERVER); ?>
</body>
</html>
