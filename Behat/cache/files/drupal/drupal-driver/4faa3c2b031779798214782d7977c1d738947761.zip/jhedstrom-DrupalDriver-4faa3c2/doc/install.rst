Installation
============

To utilize the Drupal Drivers in your own project, they are installed via composer_.

.. literalinclude:: _static/snippets/composer.json
   :language: json

and then install and run composer

.. literalinclude:: _static/snippets/composer.bash
   :language: bash

.. _composer: https://getcomposer.org/
