<?php

use Drupal\Driver\DrushDriver;

...

$alias = '@mysite';
$driver = new DrushDriver($alias);

...
