$> curl -sS http://getcomposer.org/installer | php
$> php composer.phar install
