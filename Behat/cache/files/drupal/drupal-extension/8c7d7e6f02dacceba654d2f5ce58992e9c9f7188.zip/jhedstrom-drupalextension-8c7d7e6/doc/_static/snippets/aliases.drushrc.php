<?php
$aliases['local'] = array(
  'root' => '/var/www/seven/drupal',
  'uri'  =>  'seven.l'
);
$aliases['git7site'] = array(
  'uri'  =>  'git7site.devdrupal.org',
  'host' => 'git7site.devdrupal.org'
);
